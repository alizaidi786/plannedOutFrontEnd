import React, { useEffect, useState } from "react";
import { Modal,Button,Col,Row,Form } from 'react-bootstrap'
import Axios from "../../Axios";
import 'bootstrap/dist/css/bootstrap.min.css';
import { useStoreState } from "easy-peasy";
import { ToastProvider, useToasts } from 'react-toast-notifications';
import { ToastContainer, toast } from 'react-toastify';
import '../../../node_modules/react-toastify/dist/ReactToastify.css';


export default function AddActivity(props){
    const [title, setTitle] = useState("");
    const [summary, setSummary] = useState("");
    const userId = sessionStorage.getItem("userId");
    const userID = JSON.parse(userId)
    

    const handleSubmit = (e) => {
     
      e.preventDefault();
        Axios.put("http://localhost:4000/activity", {
            userId:userID,
            title: title,
            summary: summary
          }).then((data) => {
            if (data.status === 200) {
              console.log(data.data.body.data);
              toast.success('Added Successfully!', {
                position: "top-center",
                autoClose: 1800,
                hideProgressBar: true,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                });
            } else if (data.status === 400) {
              alert("Server Down Try again after sometime");
            }
          });
          document.getElementById('close-view').click()
    }
    return(
      <div>
        <Modal
        {...props}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        id="ShortTermEditPopUp"
        centered
      >
        <Modal.Header >
          <Modal.Title className="modal-title" id="contained-modal-title-vcenter">
           Add Activity
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <Form onSubmit={handleSubmit}>

<Form.Group className="mb-3" controlId="formGridAddress1">
   <Form.Label>Title</Form.Label>
   <Form.Control placeholder="Title"  onChange={(e) => setTitle(e.target.value)}  />
 </Form.Group>

 <Form.Group className="mb-3" controlId="formGridAddress2">
   <Form.Label>Summary</Form.Label>
   <Form.Control as="textarea" rows={4}    onChange={(e) => setSummary(e.target.value)} />
 </Form.Group>  
 <Form.Group className="mb-3" controlId="formGridAddress2">
 
 <Form.Control type="file" />
 </Form.Group>
 

 <Button type="submit" className="float-end submit-btn">
   Submit
 </Button>
</Form>

        </Modal.Body>
        <Modal.Footer>
          <Button id="close-view" className="btn close-view" onClick={props.onHide}>Close</Button>
        </Modal.Footer>
      </Modal>

<ToastContainer
position="top-center"
autoClose={1800}
hideProgressBar
newestOnTop={false}
closeOnClick
rtl={false}
pauseOnFocusLoss
draggable
pauseOnHover
/>
</div>
    )
}

