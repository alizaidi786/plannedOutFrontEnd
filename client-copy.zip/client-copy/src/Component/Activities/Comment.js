import React, { useEffect, useState } from "react";
import Axios from "../../Axios";
import { Modal,Button,Col,Row,Form } from 'react-bootstrap'

export default function Comment(props){

    const[comment, setComment] = useState("")
    const[users, setAllUsers] = useState([])
    const[comments,setAllComments] = useState([])
    var particularComments = [];
    var usrName = "";
    var activity;

    const userId = sessionStorage.getItem("userId");
    const userID = JSON.parse(userId)

    useEffect(() => {
        Axios.get(`http://localhost:4000/user`).then(
          (data) => {
            if (data.data.body.status === "SUCCESS") {
                setAllUsers(data.data.body.data);
            } else if (data.data.body.status === "ERROR") {
    
            }
          }
        )
      }, [users])

      useEffect(() => {
        Axios.get(`http://localhost:4000/comment`).then(
          (data) => {
            if (data.data.body.status === "SUCCESS") {
                setAllComments(data.data.body.data);
            } else if (data.data.body.status === "ERROR") {
    
            }
          }
        )
      }, [comments])

    const handleSubmit = (e) => {
        e.preventDefault()
        Axios.put("http://localhost:4000/comment", {
          activityId: props.activities._id,
          comment: comment,
          userId: userID
          }).then((data) => { 
            if (data.status === 200) {
              console.log(data.data.body.data);
              alert("Added Succesfully");
            } else if (data.status === 400) {
              alert("Server Down Try again after sometime");
            }
          });
          
    }
    
    const getUserName = (usrId) => {
        usrName = ""
       users.map((user) => {
           if(usrId == user._id){
            usrName = user.userName
           }
       })
      }

      comments.map((comment)=>{
      
        particularComments.push(comment)
    })
    
      const showDiscussion = () => {
        document.getElementById('discussion').style.display = "block"
    }
    const hideDiscussion = () => {
      document.getElementById('discussion').style.display = "none"
  }


    return(
           <div>
            <div className="card-comments" onClick={showDiscussion} onDoubleClick={hideDiscussion}>Discussion</div>
            <div style={{display: "none"}} id="discussion">
                  {/* { activity = activities } */}
                  <Form onSubmit={handleSubmit}>
                      <Form.Group className="mb-3" controlId="formGridAddress1">
                      <Form.Control placeholder="Add a comment"  onChange={(e) => setComment(e.target.value)}  />
                      <Button type="submit" className="float-end submit-btn">
                      Add
                     </Button>
                      </Form.Group> 
                      
                   </Form>
                  { particularComments.map((discussion) => (
                      <>
                      
                      {console.log(discussion)}
                      <p>{discussion.comment}</p>
                      { getUserName(discussion.userId) }
                      <p>{usrName}</p>
                      <hr></hr>
                      </>
                  ))
                  
                  }

                  </div>

</div>
             
    )
}