import React, { useEffect, useState } from "react";
import Axios from "../../Axios";
import 'bootstrap/dist/css/bootstrap.min.css';
import Comment from "./Comment"

export default function Activities(){
    const[activities, setAllActivities] = useState([])
    const[user, setUser] = useState([])
    const[users, setAllUsers] = useState([])
    var friendsAct = [];
    var username = "";
   
    const userId = sessionStorage.getItem("userId");
    const userID = JSON.parse(userId)
    
    useEffect(() => {
        Axios.get(`http://localhost:4000/activity`).then(
          (data) => {
            if (data.data.body.status === "SUCCESS") {
                setAllActivities(data.data.body.data);
            } else if (data.data.body.status === "ERROR") {
    
            }
          }
        )
      }, [activities])

      useEffect(() => {
        Axios.get(`http://localhost:4000/user`).then(
          (data) => {
            if (data.data.body.status === "SUCCESS") {
                setAllUsers(data.data.body.data);
            } else if (data.data.body.status === "ERROR") {
    
            }
          }
        )
      }, [users])

    useEffect(() => {
      getUser()
    },[])
     
    const getUser = () => {
        Axios.get(`http://localhost:4000/user?id=${userID}`).then(
        (data) => {
            if (data.data.body.status === "SUCCESS") {
                setUser(data.data.body.data);
            } else if (data.data.body.status === "ERROR") {
    
            }
        }
    )
    }

    const getUserForName = (userId) => {
      username = ""
     users.map((user) => {
         if(userId == user._id){
           username = user.userName
         }
     })
    }

   
    var friends =  user.friends
    if(friends){
        activities.map((act) => {
           
            friends.map((friendId) => {
                
               if(act.userId === friendId){
                   friendsAct.push(act)
               }
            })
         })
     
    }

   
    const changeTime = (time) =>{
      var H = +time.substr(0, 2);
      var h = H % 12 || 12;
      var ampm = (H < 12 || H === 24) ? "AM" : "PM";
      time = h + time.substr(2, 3) + ampm;
      return time;
    }

    
    return(
        <div>
          <div className="post-header">
            <p>Friends</p>
          </div>
        { friendsAct.map((activities) => (
            <>
            { getUserForName(activities.userId)}
           
            <div className="post-card">
              <div className="header-card">{activities.title}</div>
              <div className="image-card"><img src="https://i.ytimg.com/vi/BaSf_zs3psk/hqdefault.jpg" /></div>
              <div className="summary-card">{activities.summary}</div>
              <div className="footer-card">
                <div><Comment activities = {activities} /> </div>
                <div className="card-user">{username}</div>
                <div className="card-date">{activities.createdAt.substr(0,10)} | {changeTime(activities.createdAt.substr(11,8))}</div>
              </div>
              
            </div>
            </>
        ))}
        </div>
    )
}

