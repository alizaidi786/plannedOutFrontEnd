import React, { useEffect, useState } from "react";
import Axios from "../../Axios";
import NavBar from '../Navbar/NavBar'
import './Activities.css'
import 'bootstrap/dist/css/bootstrap.min.css';
import MyActivities from './MyActivities';
import AddActivity from './AddActivity';
import PublicActivities from './PublicActivities';
import FriendsActivities from './FriendsActivities';
import { Modal,Button,Col,Row,Form } from 'react-bootstrap'

export default function Activities(){
    const [selected, setSelected] = useState("");
    const [friends, setFriends] = useState("");
    const [myact, setMyAct] = useState("");
    const [publicact, setPublic] = useState("");
    const [modalAddActivity, setModalAddActivity] = useState(false)
   
    
    
        console.log(friends);
         if(friends == "friends"){
            document.getElementById('myact').style.display = "none" ;
            document.getElementById('public').style.display = "none" ;
            document.getElementById('friends').style.display = "block" ;
            setFriends("err")
         }
         else if(myact == "my"){
            
            document.getElementById('public').style.display = "none" ;
            document.getElementById('friends').style.display = "none" ;
            document.getElementById('myact').style.display = "block" ;

            setMyAct("err")
         }
         else if(publicact == "public"){
            document.getElementById('myact').style.display = "none" ;
            document.getElementById('friends').style.display = "none" ;
            document.getElementById('public').style.display = "block" ;
            setPublic("err")
         }
  
  

     return(
         <div>
             <div className="topnav">
             <NavBar />

             </div>
            
             <div className="actMain">
                 <div className="actSide">
                    <Button onClick={() => setMyAct("my") }>My Activities</Button>
                    <Button onClick={() => setPublic("public")}>Public Activities</Button>
                    <Button onClick={() => setFriends("friends")}>Friends Activities</Button>
                    <Button onClick={() => setModalAddActivity(true)}>Add Activity</Button>
                    
                 </div>
                 <div className="actFront">
                 <AddActivity 
                    show={modalAddActivity}
                    onHide={() => setModalAddActivity(false)}
                    />
                    <div id="friends">
                    <FriendsActivities />
                    </div>
                     <div id="myact">
                     <MyActivities />
                     </div>
                     <div id="public">
                      <PublicActivities />
                     </div>
                 </div>
             </div>
         </div>
     )
}

