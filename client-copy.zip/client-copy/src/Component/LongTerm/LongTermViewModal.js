import React, { useEffect, useState } from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import './LongTerm.css'
import Axios from "../../Axios";
import { Modal,Button,Col,Row } from 'react-bootstrap'

export default function LongTermViewModal(props) { 
  const [shortTermIds, setShortTermIds] = useState([]);

  // useEffect(() => {
  //   if(props.shortTerm){
  //      let arr1 = [];
  //     props.shortTerm.map((shortId) => {
  //       Axios.get(`http://localhost:4000/shortTerm?id=${shortId}`).then(
  //         (data) => {
  //           if (data.data.body.status === "SUCCESS") {
  //             const arr2 = [...arr1,data.data.body.data]
  //             setShortTermIds(arr2)
              
  //           } else if (data.data.body.status === "ERROR") {
  //           }
  //         }
  //       );
  //     })
  //   }
  // })

  const completeGoal = () => {
    var progress = "Completed";
    Axios.post("http://localhost:4000/longTerm", {
      id: props._id,
      title: props.title,
      description: props.description,
      startDate: props.startDate,
      finishDate: props.finishDate,
      shortTerm: props.shortTerm,
      status: progress
    }).then((data) => {
      if (data.status === 200) {
        console.log(data.data.body.data);
        alert("Updated Status Succesfully");
      } else if (data.status === 400) {
        alert("Server Down Try again after sometime");
      }
    });
    
  }
    return (
      <Modal
        {...props}
        size="lg"
        aria-labelledby="contained-modal-title-vcenter"
        centered
      >
        <Modal.Header >
          <Modal.Title className="modal-title" id="contained-modal-title-vcenter">
           View Long Term Goal
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
        <Row>
            <Col>
            <h4>{props.title}</h4>
            </Col>
            <Col>
            <p style={{color:props.status === "Pending" ? 'orange' : 'green' }} >{props.status}</p>
            </Col>
          </Row>
          <p>{props.description}</p>
          <Row>
            <Col>Start Date: {props.startDate}</Col>
            <Col>Finish Date: {props.finishDate}</Col>
          </Row>
          {/* <div style={{display: shortTermIds.length === 0 ?  'none' : 'block' }}>
          <h6>Short Terms</h6>
          { shortTermIds.map((shortTermsData) =>(
            <p>{shortTermsData.title}</p>
          ))
          }
          </div> */}
           <br />
          <Button className="btn complete" onClick={completeGoal}>Completed ?</Button>
          <p>If it's completed click Completed above</p>
          
        </Modal.Body>
        <Modal.Footer>
          <Button className="btn close-view" onClick={props.onHide}>Close</Button>
        </Modal.Footer>
      </Modal>
    )
    }
