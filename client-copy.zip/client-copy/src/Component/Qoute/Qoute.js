import React from "react";
import Popup from 'reactjs-popup';
import LongTermDisplay from './LongTermDisplay'
import ShortTermDisplay from './ShortTermDisplay'
import 'reactjs-popup/dist/index.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import './Qoute.css'
import NavBar from '../Navbar/NavBar'
import { Navbar,Nav,NavDropdown,Row,Col,Container } from 'react-bootstrap'
import RandomQouteGen from "./RandomQouteGen";
import { useStoreState } from "easy-peasy";


export default function Qoute(){

    return(
       <div>
         
 <NavBar />

<Container className="contact-content debug-border">
  <Row className="align-items-center">
    <Col className="text-center text-md-right">
           <RandomQouteGen />  
    </Col>
  </Row>
  <Row>
    <Col className="text-center text-md-right" >
    <div className="goals term-card">
    <h2>Goals</h2>
    </div>
    </Col>
  </Row>
  <Row >
    <Col className="text-center text-md-right">
      
      <LongTermDisplay />
   
    </Col>
    <Col className="text-center text-md-right">
    
     <ShortTermDisplay />

    </Col>
  </Row>
</Container>
           
       </div>
    );
}