import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';
import { Navbar,Nav,NavDropdown,Container } from 'react-bootstrap'
import Popup from 'reactjs-popup';

export default function NavBar(props){

    return(
        <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark">
  <Container>
  <Navbar.Brand href="/home">Planned Out</Navbar.Brand>
  <Navbar.Toggle aria-controls="responsive-navbar-nav" />
  <Navbar.Collapse id="responsive-navbar-nav" className="justify-content-end">
    <Nav>
      <Nav.Link href="/home">Homepage</Nav.Link>
      <Nav.Link href="/activities">Activities</Nav.Link>
      <Nav.Link href="#pricing">Plan</Nav.Link>
      <Nav.Link href="#pricing">Chat</Nav.Link>
      <NavDropdown title="My Account" id="collasible-nav-dropdown">
        <NavDropdown.Item href="#action/3.1">Friends</NavDropdown.Item>
        <NavDropdown.Item href="#action/3.2">Groups</NavDropdown.Item>
        <NavDropdown.Item href="#action/3.3"><Popup trigger={<button> Click to open popup </button>} 
     position="right center">
      <div>GeeksforGeeks</div>
      <button>Click here</button>
    </Popup></NavDropdown.Item>
      </NavDropdown>
    </Nav>
  </Navbar.Collapse>
  </Container>
</Navbar>
    )
}