const responseConstant = require("../../constants/response.constants");
const db = require("../../helpers/db/index");
const response = require("../../helpers/response.maker");

module.exports.create = async (data) => {
    var Connection = await db.connectToDatabase();
  
    var ShortTermModel = Connection.model("shortterms");
    console.log("Hi db")
    var { title, description, startDate, finishDate, longTerm, status, userId } = data;
  
    let ShortTermData = {
        title,
        description,
        startDate,
        finishDate,
        longTerm,
        status,
        userId
    };
  
    var ins = new ShortTermModel(ShortTermData);
    return await ins
      .save()
      .then(async (data) => {
        return await response.success(
          responseConstant.SHORT_TERM.CREATE_SHORT_TERM_SUCCESS,
          data
        );
      })
      .catch(async (e) => {
        return await response.error(responseConstant.SHORT_TERM.CREATE_SHORT_TERM_ERROR, {
          message: e,
        });
      });
  };