const responseConstant = require("../../constants/response.constants");
const db = require("../../helpers/db/index");
const response = require("../../helpers/response.maker");

module.exports.create = async (data) => {
    var Connection = await db.connectToDatabase();
  
    var CommentModel = Connection.model("comments");
       
    var {activityId,comment, userId } = data;
  
    let CommentData = {
        activityId,
        comment,
         userId
    };
  
    var ins = new CommentModel(CommentData);
    return await ins
      .save()
      .then(async (data) => {
        return await response.success(
          responseConstant.COMMENT.CREATE_COMMENT_SUCCESS,
          data
        );
      })
      .catch(async (e) => {
        return await response.error(responseConstant.COMMENT.CREATE_COMMENT_ERROR, {
          message: e,
        });
      });
  };