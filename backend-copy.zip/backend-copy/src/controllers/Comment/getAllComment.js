const responseConstant = require("../../constants/response.constants");
const db = require("../../helpers/db/index");
const response = require("../../helpers/response.maker");

module.exports.getAll = async ( ) => {
  var Connection = await db.connectToDatabase();
  var CommentModel = Connection.model("comments");

  return await CommentModel.find( {isDeleted: {$ne: true}} )
    .then(async (data) => {
      return await response.success(
        responseConstant.COMMENT.GET_ONE_COMMENT_SUCCESS,
        data
      );
    })
    .catch(async (e) => {
      return await response.error(
        responseConstant.COMMENT.GET_ONE_COMMENT_ERROR,
        { message: e }
      );
    });
};
