const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const CommentSchema = new Schema(
    {
        activityId: Schema.Types.String,
        comment: Schema.Types.String,
        userId: Schema.Types.String,
        isDeleted: {
            type: Schema.Types.Boolean,
            default: false,
          }
    } ,  { timestamps: true }
);

let CommentModel = mongoose.model("comments", CommentSchema);
module.exports = CommentModel;